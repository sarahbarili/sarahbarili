#!/usr/bin/env bash
set -ex

npm install

cd Bootstrapper
chmod +x build.sh
./build.sh
cd ..

cd RuntimePatcher
chmod +x build.sh
./build.sh
cd ..
